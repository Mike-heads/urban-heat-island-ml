def main():
    print("Urban Heat Island ML project scaffold")

if __name__ == "__main__":
    main()
