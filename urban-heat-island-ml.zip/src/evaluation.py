# Model evaluation utilities
