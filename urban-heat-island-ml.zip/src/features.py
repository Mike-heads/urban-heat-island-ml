# Feature engineering functions
