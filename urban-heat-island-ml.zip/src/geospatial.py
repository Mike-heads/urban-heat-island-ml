# Geospatial feature engineering functions
