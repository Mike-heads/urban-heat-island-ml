# Satellite data processing functions
